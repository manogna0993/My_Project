#!/bin/bash
./obj_dir/Vtop +trace
